﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web_Prog_Project.Models
{
    public class shopmodel
    {
        public List<Catagory> cat { get; set; }
        public List<Product> prod { get; set; }
    }
}